
# Netflix Clone

This is a Netflix clone built using React and styled-components. It includes basic features like a Navbar, Banner, and movie categories (Rows).

## Setup

1. Install dependencies: `npm install`
2. Run the project: `npm start`
