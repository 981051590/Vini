import React from 'react';
import Navbar from '../components/Navbar';
import Banner from '../components/Banner';
import Row from '../components/Row';

const movieData = {
  bannerMovie: {
    title: 'The Witcher',
    image: '/images/witcher-banner.jpg',
    description: 'Geralt of Rivia, a mutated monster-hunter for hire, journeys toward his destiny in a turbulent world where people often prove more wicked than beasts.',
  },
  categories: [
    {
      title: 'Trending Now',
      movies: [
        { id: 1, title: 'Extraction', poster: '/images/extraction.jpg' },
        { id: 2, title: 'Stranger Things', poster: '/images/stranger-things.jpg' },
      ],
    },
    {
      title: 'Top Rated',
      movies: [
        { id: 3, title: 'Breaking Bad', poster: '/images/breaking-bad.jpg' },
        { id: 4, title: 'Better Call Saul', poster: '/images/better-call-saul.jpg' },
      ],
    },
  ],
};

function Home() {
  return (
    <div>
      <Navbar />
      <Banner movie={movieData.bannerMovie} />
      {movieData.categories.map((category) => (
        <Row key={category.title} title={category.title} movies={category.movies} />
      ))}
    </div>
  );
}

export default Home;