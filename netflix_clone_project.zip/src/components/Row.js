import React from 'react';
import styled from 'styled-components';

const RowContainer = styled.div`
  margin-left: 20px;
  color: white;
`;

const Title = styled.h2`
  font-size: 1.5rem;
  margin-left: 20px;
`;

const RowPosters = styled.div`
  display: flex;
  overflow-y: hidden;
  overflow-x: scroll;
  padding: 20px;
`;

const Poster = styled.img`
  width: 100%;
  max-height: 200px;
  object-fit: contain;
  margin-right: 10px;
  transition: transform 0.2s;
  &:hover {
    transform: scale(1.08);
  }
`;

function Row({ title, movies }) {
  return (
    <RowContainer>
      <Title>{title}</Title>
      <RowPosters>
        {movies.map((movie) => (
          <Poster key={movie.id} src={movie.poster} alt={movie.title} />
        ))}
      </RowPosters>
    </RowContainer>
  );
}

export default Row;