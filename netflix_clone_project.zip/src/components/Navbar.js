import React, { useState, useEffect } from 'react';
import styled from 'styled-components';

const Nav = styled.nav`
  position: fixed;
  top: 0;
  width: 100%;
  height: 50px;
  background-color: ${(props) => (props.scroll ? 'black' : 'transparent')};
  transition: background-color 0.5s;
  display: flex;
  justify-content: space-between;
  padding: 20px;
  z-index: 1;
`;

const Logo = styled.img`
  width: 100px;
  cursor: pointer;
`;

const Avatar = styled.img`
  width: 30px;
  cursor: pointer;
`;

function Navbar() {
  const [scroll, setScroll] = useState(false);

  useEffect(() => {
    window.addEventListener('scroll', () => {
      setScroll(window.scrollY > 100);
    });
    return () => window.removeEventListener('scroll', null);
  }, []);

  return (
    <Nav scroll={scroll}>
      <Logo src="/images/netflix-logo.png" alt="Netflix Logo" />
      <Avatar src="/images/netflix-avatar.png" alt="User Avatar" />
    </Nav>
  );
}

export default Navbar;