import React from 'react';
import styled from 'styled-components';

const BannerContainer = styled.header`
  background-size: cover;
  background-image: url(${(props) => props.backgroundImage});
  height: 500px;
  color: white;
  object-fit: contain;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 30px;
`;

const Title = styled.h1`
  font-size: 3rem;
  font-weight: 800;
`;

const Buttons = styled.div`
  margin-top: 20px;
`;

const Button = styled.button`
  cursor: pointer;
  color: white;
  outline: none;
  border: none;
  font-weight: 700;
  padding: 10px 20px;
  margin-right: 10px;
  background-color: rgba(51, 51, 51, 0.5);
  &:hover {
    background-color: white;
    color: black;
  }
`;

const Description = styled.p`
  max-width: 360px;
  margin-top: 10px;
  font-size: 1.2rem;
  line-height: 1.3;
`;

function Banner({ movie }) {
  return (
    <BannerContainer backgroundImage={movie.image}>
      <Title>{movie.title}</Title>
      <Buttons>
        <Button>Play</Button>
        <Button>My List</Button>
      </Buttons>
      <Description>{movie.description}</Description>
    </BannerContainer>
  );
}

export default Banner;